﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Matikala.Models
{
    public class BankBranch
    {
        public int UserTypeId { get; set; }
        public int BranchId { get; set; }
        public int BankId { get; set; }
        public int StateId { get; set; }
        public int DistrictId { get; set; }
        public string BranchName { get; set; }
        public string BranchAddr { get; set; }
        public string RTGSCode { get; set; }
        public string Contactno { get; set; }
        public string BankName { get; set; }
        public string StateName { get; set; }
        public string DistrictName { get; set; }
        public string ApplicationId { get; set; }
        public string SalutationName { get; set; }
        public string ApplicantName { get; set; }
        public decimal ProjectCapitalExpenditure { get; set; }
        public decimal ProjectWorkingCapital { get; set; }
        public decimal TotalProjectCost { get; set; }
        public string RejectRemark { get; set; }
        public string RejectedDate { get; set; }       
        public int ProcId { get; set; }
        public string msg { get; set; }
        public string BranchCode { get; set; }
        public string FinYear { get; set; }
    }
}